# vue-firebase-crud-app
This is a step by step tutorial that explains how to build a Vue.js 2+ CRUD web application using Firebase database.

[Vue.js 2 + Firebase: Build Vue CRUD App with Cloud Firestore](https://www.positronx.io/vue-js-firebase-build-vue-crud-app-with-cloud-firestore/)

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```