export class Country {
    public name: string;
    public flag: string;
}